let button;
let input;
let recommendationText = '';
let age = 0;

let movies = [
  {title: "Harry Potter e a Pedra Filosofal", genre: "Fantasia", rating: "Livre", minAge: 0},
  {title: "Vingadores: Ultimato", genre: "Ação", rating: "12 anos", minAge: 12},
  {title: "O Rei Leão", genre: "Animação", rating: "Livre", minAge: 0},
  {title: "O Senhor dos Anéis: A Sociedade do Anel", genre: "Fantasia", rating: "12 anos", minAge: 12},
  {title: "O Exorcista", genre: "Terror", rating: "18 anos", minAge: 18},
  {title: "Forrest Gump", genre: "Drama", rating: "10 anos", minAge: 10},
  {title: "Jurassic Park", genre: "Aventura", rating: "10 anos", minAge: 10},
  {title: "Star Wars: Uma Nova Esperança", genre: "Ficção Científica", rating: "Livre", minAge: 0},
  {title: "A Bela e a Fera", genre: "Animação", rating: "Livre", minAge: 0},
  {title: "Matrix", genre: "Ação", rating: "16 anos", minAge: 16},
  {title: "O Lobo de Wall Street", genre: "Comédia", rating: "18 anos", minAge: 18},
  {title: "Os Vingadores", genre: "Ação", rating: "12 anos", minAge: 12},
  {title: "Toy Story", genre: "Animação", rating: "Livre", minAge: 0},
  {title: "Deadpool", genre: "Ação", rating: "18 anos", minAge: 18},
  {title: "Coco", genre: "Animação", rating: "Livre", minAge: 0}
];

function setup() {
  createCanvas(400, 300);
  
  // Campo de entrada de idade
  input = createInput();
  input.position(20, 50);
  
  // Botão para gerar recomendação
  button = createButton('Start');
  button.position(20, 80);
  button.mousePressed(recommendMovie);
}

function recommendMovie() {
  age = int(input.value()); // pega a idade do input
  
  // Encontrar filmes adequados para a idade inserida
  let availableMovies = movies.filter(movie => age >= movie.minAge);
  
  if (availableMovies.length > 0) {
    let randomIndex = floor(random(availableMovies.length));
    let movie = availableMovies[randomIndex];
    recommendationText = `Recomendação: ${movie.title}\nGênero: ${movie.genre}\nClassificação: ${movie.rating}`;
  } else {
    recommendationText = "Nenhum filme disponível para essa idade!";
  }
}

function draw() {
  background(240);
  
  // Exibe o título e a área de recomendação
  textSize(18);
  textAlign(CENTER);
  text("Seletor de Filmes", width / 2, 20);
  
  textSize(14);
  textAlign(LEFT);
  text("Digite sua idade:", 20, 40);
  
  // Exibe o resultado da recomendação
  textSize(16);
  textAlign(CENTER);
  text(recommendationText, width / 2, 150);
}
